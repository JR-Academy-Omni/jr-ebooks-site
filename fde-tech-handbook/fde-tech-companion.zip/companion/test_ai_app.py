"""Deterministic failure/control checks; injected responses are not LLM runs."""
import copy
import json
import unittest
from ai_app import ask, post_model, ModelUnavailable
from lab import load_data

def good(payload):
    evidence = json.loads(payload['messages'][1]['content'])['documents'][0]
    return {'choices': [{'finish_reason': 'stop', 'message': {'content': json.dumps({
        'answer': evidence['text'], 'citation_ids': [evidence['id']]})}}]}

class Controls(unittest.TestCase):
    def test_denied_does_not_call_model(self):
        def forbidden(_):
            self.fail('Model must not receive a denied or empty retrieval')
        for user, question, status in [
            ('ops_alice','关账','no_evidence'),('ops_alice','育儿假','no_evidence'),
            ('nobody','差旅','unauthorized'),('disabled_dan','关账','unauthorized'),
            ('fin_bob','差旅和关账','needs_review'),('ops_alice','未分类','no_evidence')]:
            with self.subTest(user=user,question=question):
                r=ask(user,question,transport=forbidden)
                self.assertEqual(r['status'],status)
                self.assertFalse(r['model_called'])

    def test_payload_filters_private_retired_other_tenant(self):
        def inspect(payload):
            s=json.dumps(payload,ensure_ascii=False)
            for secret in ['FIN-DEMO-42','B-ONLY-17','无需预先审批','orphan']:
                self.assertNotIn(secret,s)
            return good(payload)
        r=ask('ops_alice','差旅申请',transport=inspect)
        self.assertEqual(r['status'],'draft')
        self.assertEqual(r['citations'][0]['id'],'travel-v2')

    def test_revocation_before_next_generation(self):
        d=copy.deepcopy(load_data())
        self.assertEqual(ask('fin_bob','关账',data=d,transport=good)['status'],'draft')
        d['users']['fin_bob']['groups']=['ops']
        self.assertEqual(ask('fin_bob','关账',data=d,transport=good)['status'],'no_evidence')

    def test_untrusted_output_is_not_returned(self):
        for draft in [None,{}, {'answer':'bad-private-output','citation_ids':['finance-close']},
                      {'answer':'bad-private-output','citation_ids':[]},
                      {'answer':'','citation_ids':['travel-v2']},
                      {'answer':'bad-private-output','citation_ids':'travel-v2'}]:
            def transport(_):
                return {'choices':[{'finish_reason':'stop','message':{'content':json.dumps(draft)}}]}
            with self.subTest(draft=draft):
                r=ask('ops_alice','差旅',transport=transport)
                self.assertEqual(r['status'],'needs_review')
                self.assertNotIn('bad-private-output',json.dumps(r))

    def test_truncation_refusal_and_missing_message(self):
        for response in [{}, {'choices':[]},
                         {'choices':[{'finish_reason':'length','message':{'content':'{}'}}]},
                         {'choices':[{'finish_reason':'stop','message':{'refusal':'No'}}]}]:
            with self.subTest(response=response):
                self.assertEqual(ask('ops_alice','差旅',transport=lambda _:response)['status'],'needs_review')

    def test_model_failure_is_not_no_evidence(self):
        def fail(_): raise ModelUnavailable()
        self.assertEqual(ask('ops_alice','差旅',transport=fail)['status'],'service_unavailable')

    def test_bad_inputs(self):
        for q in ['', ' '*4, 'x'*2001]:
            self.assertEqual(ask('ops_alice',q,transport=good)['status'],'invalid_input')

    def test_local_only_transport(self):
        for endpoint in ['https://example.com/v1/chat/completions','http://example.com',
                         'http://user:pass@localhost:8089']:
            with self.assertRaises(ValueError): post_model({},endpoint)

if __name__ == '__main__': unittest.main(verbosity=2)
