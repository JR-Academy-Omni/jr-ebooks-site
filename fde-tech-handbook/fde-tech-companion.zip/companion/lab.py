"""Offline teaching lab. Trusted CLI fixtures; NOT an authentication service or LLM."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def load_data():
    return json.loads((ROOT / 'data.json').read_text(encoding='utf-8'))

def answer(principal, question, data=None):
    data = load_data() if data is None else data
    user = data['users'].get(principal)
    if not user or not user.get('active'):
        return {'status': 'unauthorized', 'answer': '身份无效', 'citations': []}
    # Filter by server-side identity BEFORE matching, ranking, or answering.
    visible = [d for d in data['documents']
               if d.get('status') == 'current'
               and d.get('tenant') == user['tenant']
               and ('all' in d.get('groups', [])
                    or set(user['groups']).intersection(d.get('groups', [])))]
    hits = [d for d in visible if any(k in question for k in d['keywords'])]
    if not hits:
        return {'status': 'no_evidence', 'answer': '未找到可用依据，请联系资料负责人。', 'citations': []}
    if len(hits) > 1:
        return {'status': 'needs_review', 'answer': '存在多份相关资料，请人工核对。', 'citations': []}
    doc = hits[0]
    return {'status': 'answered', 'answer': doc['text'],
            'citations': [{'id': doc['id'], 'version': doc['version']}]}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--user', required=True, help='Trusted local fixture only')
    parser.add_argument('--question', required=True)
    args = parser.parse_args()
    print(json.dumps(answer(args.user, args.question), ensure_ascii=False, indent=2))
