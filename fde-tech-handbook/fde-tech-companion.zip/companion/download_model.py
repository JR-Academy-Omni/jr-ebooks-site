"""Download the pinned official teaching model and verify its SHA-256."""
import hashlib
from pathlib import Path
import urllib.request

REVISION = '9217f5db79a29953eb74d5343926648285ec7e67'
NAME = 'qwen2.5-0.5b-instruct-q4_k_m.gguf'
SHA256 = '74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db'
URL = 'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/' + REVISION + '/' + NAME

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def main():
    folder = Path(__file__).resolve().parent / 'models'
    folder.mkdir(exist_ok=True)
    target = folder / NAME
    if target.exists() and digest(target) == SHA256:
        print('Already verified:', target.name)
        return
    partial = target.with_suffix('.gguf.part')
    print('Downloading 491,400,032 bytes from official Qwen repository...', flush=True)
    with urllib.request.urlopen(URL, timeout=90) as response, partial.open('wb') as out:
        for block in iter(lambda: response.read(1024*1024), b''):
            out.write(block)
    if digest(partial) != SHA256:
        partial.unlink()
        raise SystemExit('SHA-256 mismatch; downloaded file removed. Retry the official source.')
    partial.replace(target)
    print('SHA-256 verified:', target.name)

if __name__ == '__main__':
    main()
