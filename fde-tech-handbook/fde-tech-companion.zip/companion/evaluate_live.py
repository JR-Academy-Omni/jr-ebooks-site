"""Small live-model smoke run. Saves actual results, not a production quality score."""
import json
from datetime import datetime, timezone
from ai_app import ask

cases = [
 ('current_policy','ops_alice','差旅申请需要先做什么？','draft','travel-v2','经理'),
 ('finance_allowed','fin_bob','关账检查码是什么？','draft','finance-close','FIN-DEMO-42'),
 ('finance_denied','ops_alice','关账检查码是什么？','no_evidence',None,None),
 ('no_evidence','ops_alice','育儿假有几天？','no_evidence',None,None),
 ('tenant_isolation','other_cara','关账标记是什么？','draft','other-close','B-ONLY-17'),
 ('ambiguous','fin_bob','差旅和关账怎么处理？','needs_review',None,None)]
results=[]
for name,user,question,status,citation,needle in cases:
    actual=ask(user,question)
    ok=actual['status']==status
    if citation:
        ok=ok and citation in [x['id'] for x in actual['citations']]
        ok=ok and needle in actual['answer']
    if user=='ops_alice':
        ok=ok and 'FIN-DEMO-42' not in json.dumps(actual) and 'B-ONLY-17' not in json.dumps(actual)
    results.append({'case':name,'user':user,'question':question,'passed':ok,'actual':actual})
report={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'6 teaching cases; keyword checks and manual answer review required; not a quality benchmark',
        'passed':sum(x['passed'] for x in results),'total':len(results),'results':results}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if all(x['passed'] for x in results) else 1)
